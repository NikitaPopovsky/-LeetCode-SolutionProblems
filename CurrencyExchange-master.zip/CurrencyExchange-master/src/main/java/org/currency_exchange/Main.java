package org.currency_exchange;

import org.currency_exchange.db.CurrencyDAO;
import org.currency_exchange.db.ExchangeRateDAO;
import org.currency_exchange.model.Currency;

import java.util.Optional;

public class Main {
    public static void main(String[] args) {
    //test findByCode
    //        CurrencyDAO currencyDAO = new CurrencyDAO();
    //        Optional<Currency> currencyOptional = currencyDAO.findByCode ("RUB");

    //test save
//            CurrencyDAO currencyDAO = new CurrencyDAO();
//            currencyDAO.save (new Currency("RUB", "Rubil", "R"));
        //test findAll ExchangeRateDAO
//        ExchangeRateDAO exchangeRateDAO = new ExchangeRateDAO();
//        exchangeRateDAO.findAll();
    }
}
