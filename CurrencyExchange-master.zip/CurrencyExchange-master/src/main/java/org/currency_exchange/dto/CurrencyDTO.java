package org.currency_exchange.dto;

public record CurrencyDTO (int id, String code, String fullName, String sign) {
}

