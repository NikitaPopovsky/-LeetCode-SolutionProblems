package org.currency_exchange.model;

public record Currency(int id, String code, String fullName, String sign) {
}
